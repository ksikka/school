% Homework12Part2stubV2.m
%
% calculate features from the image files for the two classes
[filenames1,feats1]=readandcalctexturefeats('*H7*.jpg',1);
[filenames2,feats2]=readandcalctexturefeats('*G5*.jpg',1);
%
% make a vector containing the class labels (1=H7, 2=G5)
y=ones(1,length(filenames1));
y=[y 2*ones(1,length(filenames2))]';
%
% combine the feature matrices for the two classes
x=[feats1; feats2];

% add code below to complete the assignment 

% train the classifier

[v2, acc2, err2] = crossvalclassifier(x,y,2,10);
[v3, acc3, err3] = crossvalclassifier(x,y,3,10);
[v4, acc4, err4] = crossvalclassifier(x,y,4,10);
[v5, acc5, err5] = crossvalclassifier(x,y,5,10);
[v6, acc6, err6] = crossvalclassifier(x,y,6,10);

disp(v6(1)); % actual
disp(v6(2)); % predicted

hold off;
hold on;

errorbar(2,acc2,err2);
errorbar(3,acc3,err3);
errorbar(4,acc4,err4);
errorbar(5,acc5,err5);
errorbar(6,acc6,err6);

hold off;




int isAsciiDigit(int);
int test_isAsciiDigit(int);
int anyEvenBit();
int test_anyEvenBit();
int copyLSB(int);
int test_copyLSB(int);
int leastBitPos(int);
int test_leastBitPos(int);
int divpwr2(int, int);
int test_divpwr2(int, int);
int conditional(int, int, int);
int test_conditional(int, int, int);
int isNonNegative(int);
int test_isNonNegative(int);
int isGreater(int, int);
int test_isGreater(int, int);
int absVal(int);
int test_absVal(int);
int isPower2(int);
int test_isPower2(int);
int bitCount(int);
int test_bitCount(int);
unsigned float_neg(unsigned);
unsigned test_float_neg(unsigned);
unsigned float_i2f(int);
unsigned test_float_i2f(int);
